https://qaardvark.github.io/hazarda/
